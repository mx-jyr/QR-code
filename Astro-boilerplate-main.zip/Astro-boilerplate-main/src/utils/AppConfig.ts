export const AppConfig = {
  site_name: 'Astro boilerplate',
  title: 'Astro boilerplate',
  description: 'Boilerplate built with Astro using React and Tailwind CSS',
  author: 'Emma',
  locale_region: 'en-us',
  locale: 'en',
};
