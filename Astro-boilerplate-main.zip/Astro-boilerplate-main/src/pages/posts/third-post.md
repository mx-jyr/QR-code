---
layout: '@/templates/BasePost.astro'
title: 3rd Lorem ipsum dolor sit
description: Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur vero esse non molestias eos excepturi.
pubDate: 2020-02-03T00:00:00Z
imgSrc: '/assets/images/image-post4.jpeg'
imgAlt: 'Image post 4'
---

Full typography example at [this page](../sixth-post/).
