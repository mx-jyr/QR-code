---
layout: '@/templates/BasePost.astro'
title: 1st Lorem ipsum dolor sit
description: Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur vero esse non molestias eos excepturi.
pubDate: 2020-02-01T00:00:00Z
imgSrc: '/assets/images/image-post7.jpeg'
imgAlt: 'Image post 7'
---

Full typography example at [this page](../sixth-post/).
