---
layout: '@/templates/BasePost.astro'
title: Hello Lorem ipsum dolor sit
description: Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur vero esse non molestias eos excepturi.
pubDate: 2020-01-01T00:00:00Z
imgSrc: '/assets/images/image-post6.jpeg'
imgAlt: 'Image post 6'
---

Full typography example at [this page](../sixth-post/).
