---
layout: '@/templates/BasePost.astro'
title: 4th Lorem ipsum dolor sit
description: Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur vero esse non molestias eos excepturi.
pubDate: 2020-02-04T00:00:00Z
imgSrc: '/assets/images/image-post3.jpeg'
imgAlt: 'Image post 3'
---

Full typography example at [this page](../sixth-post/).
