---
layout: '@/templates/BasePost.astro'
title: 2nd Lorem ipsum dolor sit
description: Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur vero esse non molestias eos excepturi.
pubDate: 2020-02-02T00:00:00Z
imgSrc: '/assets/images/image-post5.jpeg'
imgAlt: 'Image post 5'
---

Full typography example at [this page](../sixth-post/).
